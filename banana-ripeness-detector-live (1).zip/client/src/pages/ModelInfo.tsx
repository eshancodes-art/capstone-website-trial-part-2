import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, ArrowRight, BrainCircuit, Camera, CheckCircle2, CircleDot, GitBranch, Layers3, ScanSearch, SlidersHorizontal, Sparkles } from "lucide-react";

const pipeline = [
  { step: "01", icon: Camera, title: "Capture", text: "A controlled camera frame enters the pipeline with its file type, size, and capture metadata validated before inference." },
  { step: "02", icon: ScanSearch, title: "Detect", text: "The banana detector locates each visible fruit or plantain region instead of treating the image as one average sample." },
  { step: "03", icon: BrainCircuit, title: "Classify", text: "Each region is mapped to a ripeness stage using color, shape, and learned visual features from the supplied model workflow." },
  { step: "04", icon: GitBranch, title: "Group & route", text: "Mode-specific rules aggregate results, flag outliers, and produce an operator-ready routing directive." },
];

const stages = [
  ["01", "Dark green", "Harvest-ready plantain or very early banana"],
  ["02", "Light green", "Firm fruit with the first color transition"],
  ["03", "More green than yellow", "Early turning stage"],
  ["04", "More yellow than green", "Balanced transition stage"],
  ["05", "Yellow, green tips", "Dispatch-ready ripeness"],
  ["06", "Full yellow", "Peak retail ripeness"],
  ["07", "Flecking", "Overripe or review-required fruit"],
];

const modes = [
  { name: "Plantain", code: "01", text: "Optimized for maturation stages and the slower color transition of plantain." },
  { name: "Banana Bunch", code: "02", text: "Detects and grades multiple fruits in a cluster, then highlights disagreement." },
  { name: "Advanced / Custom", code: "03", text: "Groups results around flexible parameters such as color, size, or operator-defined sorting rules." },
];

export default function ModelInfo() {
  const [threshold, setThreshold] = useState(82);
  return <div className="algorithm-page">
    <header className="algorithm-header">
      <div className="algorithm-wrap algorithm-header-inner">
        <Link href="/" className="algorithm-brand">Ripe<span>Vision</span></Link>
        <div className="algorithm-header-actions"><span>MODEL NOTEBOOK / 2026</span><Link href="/model" className="algorithm-link"><ArrowRight size={15} /> Open detector</Link></div>
      </div>
    </header>
    <main>
      <section className="algorithm-hero algorithm-wrap">
        <Link href="/" className="algorithm-back"><ArrowLeft size={14} /> Back to RipeVision</Link>
        <div className="algorithm-kicker"><Sparkles size={14} /> HOW THE MODEL THINKS</div>
        <h1>From peel color to a decision the packhouse can use.</h1>
        <p className="algorithm-lede">RipeVision separates the image into fruit-level evidence, applies a ripeness classifier, and converts the result into a clear action. The system is designed to catch one out-of-step banana before it becomes a whole-container problem.</p>
        <div className="algorithm-hero-actions"><Link href="/model" className="algorithm-cta">Run an analysis <ArrowRight size={16} /></Link><a href="#pipeline" className="algorithm-text-link">Explore the pipeline <ArrowRight size={14} /></a></div>
        <div className="algorithm-summary" data-pop><div><strong>Fruit-level</strong><span>evidence</span></div><div><strong>07</strong><span>ripeness stages</span></div><div><strong>03</strong><span>operator modes</span></div><div><strong>42 ms</strong><span>adapter target</span></div></div>
      </section>

      <section id="pipeline" className="algorithm-section algorithm-section-dark">
        <div className="algorithm-wrap"><div className="algorithm-section-heading"><div><span className="algorithm-kicker">THE INFERENCE PIPELINE</span><h2>Four decisions, one traceable result.</h2></div><span className="algorithm-side-note">CAPTURE → DETECT → CLASSIFY → ROUTE</span></div>
          <div className="pipeline-grid">{pipeline.map(({ step, icon: Icon, title, text }) => <article className="pipeline-card" key={step}><div className="pipeline-card-top"><span>{step}</span><Icon size={19} /></div><h3>{title}</h3><p>{text}</p><div className="pipeline-line" /></article>)}</div>
        </div>
      </section>

      <section className="algorithm-section algorithm-wrap"><div className="algorithm-two-col"><div><span className="algorithm-kicker">WHAT THE DETECTOR SEES</span><h2>Fruit-level regions, not a single average.</h2><p>Object detection creates a region for each visible banana. That gives the classifier a clean crop and lets the bunch view compare fruit against fruit. A bunch with six healthy readings and one outlier should not be flattened into one safe-looking average.</p><div className="algorithm-checks"><span><CheckCircle2 size={16} /> Secure image validation</span><span><CheckCircle2 size={16} /> One result per visible fruit</span><span><CheckCircle2 size={16} /> Mode-aware aggregation</span></div></div><div className="algorithm-diagram"><div className="diagram-camera"><Camera size={18} /><span>IMAGE</span></div><div className="diagram-arrow">→</div><div className="diagram-fruit"><CircleDot size={18} /><span>REGIONS</span><i /><i /><i /></div><div className="diagram-arrow">→</div><div className="diagram-score"><BrainCircuit size={18} /><span>STAGES</span><strong>01—07</strong></div></div></div></section>

      <section className="algorithm-section algorithm-stage-section"><div className="algorithm-wrap"><div className="algorithm-section-heading"><div><span className="algorithm-kicker">THE RIPENESS SCALE</span><h2>Seven stages the operator can understand.</h2></div><span className="algorithm-side-note">COLOR IS THE COMMON LANGUAGE</span></div><div className="stage-grid">{stages.map(([number, name, text]) => <article className={`stage-card stage-${number}`} key={number}><div className="stage-swatch" /><strong>{number}</strong><h3>{name}</h3><p>{text}</p></article>)}</div></div></section>

      <section className="algorithm-section algorithm-wrap"><div className="algorithm-section-heading"><div><span className="algorithm-kicker">THREE OPERATING MODES</span><h2>One detector, three ways to sort.</h2></div><span className="algorithm-side-note">SELECT BEFORE UPLOAD</span></div><div className="mode-explainer-grid">{modes.map((mode) => <article className="mode-explainer" key={mode.code}><span className="mode-number">{mode.code}</span><div><h3>{mode.name}</h3><p>{mode.text}</p></div><ArrowRight size={16} /></article>)}</div></section>

      <section className="algorithm-section algorithm-section-dark"><div className="algorithm-wrap algorithm-two-col operator-explanation"><div><span className="algorithm-kicker">CONFIDENCE IS A CONTROL</span><h2>The threshold changes what deserves attention.</h2><p>The confidence slider is an operator control, not a decorative meter. Raising it makes the workflow more selective; lowering it surfaces more uncertain fruit for review. The live result cards update with the selected threshold so the operator can see the trade-off before saving.</p></div><div className="threshold-card"><div><SlidersHorizontal size={18} /><span>CONFIDENCE THRESHOLD</span><strong>{threshold}%</strong></div><div className="threshold-track"><i style={{ width: `${threshold}%` }} /></div><input aria-label="Confidence threshold" className="algorithm-threshold-input" type="range" min="40" max="99" value={threshold} onChange={(event) => setThreshold(Number(event.target.value))} /><div className="threshold-labels"><span>More review</span><span>More selective</span></div></div></div></section>

      <section className="algorithm-section algorithm-wrap algorithm-final"><span className="algorithm-kicker">READY TO OPERATE</span><h2>See the model contract in action.</h2><p>Upload a single image, choose the mode that matches the job, and leave with a result that explains not only what the camera saw—but what to do next.</p><Link href="/model" className="algorithm-cta">Open the operator view <ArrowRight size={16} /></Link></section>
    </main>
    <footer className="algorithm-footer"><div className="algorithm-wrap"><span>RipeVision · TKH Capstone 2026</span><Link href="/">Return home</Link></div></footer>
  </div>;
}
