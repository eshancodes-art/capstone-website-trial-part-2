import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowRight, Camera, ChevronRight, RotateCcw, ScanLine, ShieldCheck, Sparkles } from "lucide-react";

type Stage = { n: number; label: string; color: string };
const stages: Stage[] = [
  { n: 1, label: "Dark green", color: "#1d5527" },
  { n: 2, label: "Light green", color: "#2e7a33" },
  { n: 3, label: "More green than yellow", color: "#7fa23a" },
  { n: 4, label: "More yellow than green", color: "#c6bc2e" },
  { n: 5, label: "Yellow, green tips", color: "#f0c119" },
  { n: 6, label: "Full yellow", color: "#f7d93b" },
  { n: 7, label: "Flecking", color: "#edd061" },
];

function Banana({ stage, flagged, done }: { stage: number; flagged?: boolean; done: boolean }) {
  const color = stages[stage - 1]?.color ?? "#2e7a33";
  return <div className={`rv-banana ${flagged ? "flagged" : ""} ${done ? "done" : ""}`}>
    <svg viewBox="0 0 120 120" aria-label={`Banana at colour stage ${stage}`} role="img"><path d="M96 20C88 66 60 96 22 104C56 82 78 54 80 20C82 12 94 12 96 20Z" fill={done ? color : "#a4b19c"} /><path d="M88 22C88 12 98 10 100 18C101 24 96 28 90 27Z" fill="#9a6420" opacity=".85" /></svg>
    <span>{done ? `Stage ${stage}${flagged ? " · out of step" : ""}` : "reading…"}</span>
  </div>;
}

export default function Landing() {
  const [scan, setScan] = useState(false);
  const [finished, setFinished] = useState(false);
  const [run, setRun] = useState(0);
  const scanStages = useMemo(() => [2, 2, 2, 3, 5, 2, 2], []);
  useEffect(() => {
    const intro = window.setTimeout(() => setScan(true), 420);
    return () => window.clearTimeout(intro);
  }, []);
  useEffect(() => {
    if (!scan) return;
    setFinished(false);
    const timer = window.setTimeout(() => setFinished(true), 2400);
    return () => window.clearTimeout(timer);
  }, [scan, run]);
  const runScan = () => { setScan(false); window.setTimeout(() => { setRun((value) => value + 1); setScan(true); }, 40); };
  return <div className="rv-site">
    <header className="rv-mast"><div className="rv-wrap rv-mast-inner"><Link href="/" className="rv-logo">Ripe<span>Vision</span></Link><span className="rv-tag">A vision for a riper tomorrow</span><div className="rv-meta"><span>TKH Capstone 2026</span><Link href="/algorithm" className="rv-model-link">How it works <ArrowRight size={14} /></Link><Link href="/model" className="rv-model-link">Open detector <ArrowRight size={14} /></Link></div></div></header>
    <main>
      <section className="rv-hero rv-wrap"><span className="rv-pill">Computer vision for the banana cold chain</span><h1>One early banana ripens the whole container.</h1><p className="rv-lede">RipeVision reads the ripeness stage of every banana in a bunch — not the average of the box — and raises a signal the moment one is out of step with the rest.</p><div className="rv-hero-actions"><Link href="/model" className="rv-cta">Try the detector <ArrowRight size={17} /></Link><a href="#how" className="rv-text-link">See how it works <ChevronRight size={15} /></a></div></section>
      <section className="rv-scanner"><div className="rv-wrap"><div className="rv-scan-head"><div><strong>Bunch 04821</strong><span>Packhouse line 2 · grading station</span></div><button onClick={runScan}><RotateCcw size={15} /> Run scan again</button></div><div className={`rv-strip ${scan ? "scanning" : ""}`} key={run}><div className="rv-beam" />{scanStages.map((stage, index) => <Banana key={index} stage={stage} flagged={index === 4} done={scan && (finished || index < 5)} />)}</div><div className={`rv-readout ${finished ? "alarm" : ""}`}><i /> <span>{finished ? "Banana 5 is three stages ahead of the bunch." : scan ? "Scanning 7 bananas…" : "Ready for a live scan"}</span>{finished && <b>Signal sent to line control</b>}</div></div></section>
      <section className="rv-band"><div className="rv-wrap rv-split"><div><p className="rv-eyebrow">The problem</p><h2>A box is only as green as its greenest banana, and only as safe as its ripest one.</h2><p>Bananas are cut and shipped hard and green, then held near 13 °C so they stop ripening in transit. At the destination they are brought up to the colour the buyer ordered. The whole system assumes the fruit starts at roughly the same stage. It often doesn’t.</p></div><div className="rv-facts"><div><strong>13 °C</strong><span>Reefer set point for green fruit. The margin is thin either way.</span></div><div><strong>1 ppm</strong><span>Ethylene dose used in the ripening room for about a day.</span></div><div><strong>30%+</strong><span>Share of Indian banana production lost after harvest.</span></div><div><strong>$15 bn</strong><span>Annual value of world banana exports.</span></div><div><strong>114M t</strong><span>Metric tons of bananas wasted every year — a signal to catch the loss earlier.</span></div></div></div></section>
      <section className="rv-section rv-wrap"><p className="rv-eyebrow">What we grade against</p><h2>The trade already has a language for ripeness. We made a camera that speaks it.</h2><p className="rv-lede">Peel colour is graded on a seven-point scale, from hard dark green through to yellow flecked with brown. RipeVision outputs a stage on this same scale for every individual banana.</p><div className="rv-scale">{stages.map((stage) => <figure key={stage.n} className={stage.n === 3 || stage.n === 4 ? "marked" : ""}><Banana stage={stage.n} done /><figcaption><b>{stage.n}</b>{stage.label}</figcaption></figure>)}</div></section>
      <section id="how" className="rv-section rv-section-soft"><div className="rv-wrap rv-split"><div><p className="rv-eyebrow">How it works</p><h2>Capture, classify, flag — on a board that costs less than a crate of fruit.</h2><p className="rv-lede">The model is trained and running. The rig around it is deliberately cheap, because a grading station needs dozens of these, not one.</p></div><div className="rv-steps"><div><b>01</b><span><strong>The camera sees the whole bunch</strong><small>Fixed colour-controlled light makes peel colour comparable across shifts.</small></span></div><div><b>02</b><span><strong>The model grades each banana</strong><small>Bananas in, independent banana readings out.</small></span></div><div><b>03</b><span><strong>Disagreement raises the signal</strong><small>A lamp, buzzer, and upstream record catch the bunch before boxing.</small></span></div></div></div></section>
      <section className="rv-band rv-rig"><div className="rv-wrap rv-split"><div><p className="rv-eyebrow">The rig</p><h2>Built from parts a packhouse can already buy.</h2><p>Nothing here needs a lab. The unit can be bolted over a belt, wired to a lamp, and repeated down the line without a server room behind it.</p></div><ul><li><b><Camera size={16} /> ESP32-CAM</b><span>Image capture over the belt</span></li><li><b><ScanLine size={16} /> Fixed LED light box</b><span>Constant colour temperature for stable readings</span></li><li><b><ShieldCheck size={16} /> Sealed housing</b><span>Washdown-tolerant for a wet packing environment</span></li><li><b><Sparkles size={16} /> Wi-Fi uplink</b><span>Per-hand readings logged to the QC record</span></li></ul></div></section>
      <section className="rv-section rv-wrap rv-ask"><p className="rv-eyebrow">The ask</p><h2>Give us one packhouse, one belt, and one season.</h2><p className="rv-lede">We have the model. We are building the box. What turns this from a capstone into a product is fruit moving past a real camera on a real line.</p><Link href="/model" className="rv-cta">Open the operator model <ArrowRight size={17} /></Link></section>
    </main>
    <footer className="rv-footer"><div className="rv-wrap"><strong>RipeVision</strong> · A vision for a riper tomorrow · TKH Capstone 2026</div></footer>
  </div>;
}
