import { useEffect, useRef } from "react";
import { animate, splitText, stagger } from "animejs";

type MotionElement = HTMLElement & { __motionBound?: boolean };

function ScrollBanana() {
  const bananaRef = useRef<HTMLDivElement>(null);
  const rotation = useRef(0);
  useEffect(() => {
    const node = bananaRef.current;
    if (!node) return;
    const intro = animate(node, { opacity: [0, 0.92], translateY: [28, 0], scale: [0.88, 1], duration: 900, ease: "out(4)" });
    let scrollFrame = 0;
    let scrollTarget = window.scrollY;
    const renderScroll = () => {
      scrollFrame = 0;
      rotation.current = scrollTarget * 0.22;
      animate(node, { rotate: rotation.current, translateY: Math.sin(scrollTarget / 180) * 10, duration: 520, ease: "out(3)" });
    };
    const onScroll = () => { scrollTarget = window.scrollY; if (!scrollFrame) scrollFrame = window.requestAnimationFrame(renderScroll); };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => { intro.pause(); if (scrollFrame) window.cancelAnimationFrame(scrollFrame); window.removeEventListener("scroll", onScroll); };
  }, []);
  return <div className="scroll-banana-orbit" aria-hidden="true"><div className="scroll-banana" ref={bananaRef}>
    <span className="scroll-banana-label">SCROLL / RIPEN</span>
    <svg viewBox="0 0 180 260" role="presentation"><defs><linearGradient id="scrollBananaGold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#ffe88b" /><stop offset="0.52" stopColor="#f6c746" /><stop offset="1" stopColor="#a96d1d" /></linearGradient></defs><ellipse cx="90" cy="230" rx="58" ry="10" fill="#132015" opacity=".15" /><path d="M128 28C122 98 91 158 36 205c45-26 87-70 103-130 7-25 2-44-11-47Z" fill="url(#scrollBananaGold)" stroke="#8c611f" strokeWidth="2" /><path d="M128 28c-4-14 5-23 16-20 9 2 13 11 8 19-6 8-14 9-24 1Z" fill="#4d361b" /><path d="M43 202c-10 12-19 16-29 14" fill="none" stroke="#7c5520" strokeWidth="8" strokeLinecap="round" /><path d="M118 48C110 104 83 153 52 181" fill="none" stroke="#fff2aa" strokeWidth="8" opacity=".42" strokeLinecap="round" /></svg>
  </div></div>;
}

function ScrollProgress() {
  const progressRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = progressRef.current;
    if (!node) return;
    let frame = 0;
    const update = () => {
      frame = 0;
      const max = document.documentElement.scrollHeight - window.innerHeight;
      const progress = max > 0 ? window.scrollY / max : 0;
      animate(node, { width: `${Math.max(0, Math.min(1, progress)) * 100}%`, duration: 380, ease: "out(3)" });
    };
    const onScroll = () => { if (!frame) frame = window.requestAnimationFrame(update); };
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    update();
    return () => { if (frame) window.cancelAnimationFrame(frame); window.removeEventListener("scroll", onScroll); window.removeEventListener("resize", onScroll); };
  }, []);
  return <div className="liquid-scroll-progress" aria-hidden="true"><div ref={progressRef} className="liquid-scroll-progress-fill" /></div>;
}

function CursorFollower() {
  const followerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = followerRef.current;
    if (!node || window.matchMedia("(pointer: coarse)").matches) return;
    let frame = 0;
    let x = -40;
    let y = -40;
    const render = () => { frame = 0; animate(node, { translateX: x, translateY: y, opacity: 1, duration: 420, ease: "out(4)" }); };
    const onMove = (event: PointerEvent) => { x = event.clientX - 18; y = event.clientY - 18; if (!frame) frame = window.requestAnimationFrame(render); };
    const onLeave = () => animate(node, { opacity: 0, duration: 180, ease: "out(3)" });
    window.addEventListener("pointermove", onMove, { passive: true });
    document.documentElement.addEventListener("mouseleave", onLeave);
    return () => { if (frame) window.cancelAnimationFrame(frame); window.removeEventListener("pointermove", onMove); document.documentElement.removeEventListener("mouseleave", onLeave); };
  }, []);
  return <div ref={followerRef} className="cursor-follower" aria-hidden="true"><span /></div>;
}

function bindMotion() {
  const interactive = Array.from(document.querySelectorAll<MotionElement>("button, a, select, input[type='range']"));
  interactive.forEach((element) => {
    if (element.__motionBound) return;
    element.__motionBound = true;
    const mainAction = element.matches(".rv-cta, .primary-button, .secondary-button, .rv-scan-head button, .new-record-button, .control-actions button, .algorithm-cta");
    const enter = () => animate(element, { scale: mainAction ? 1.075 : 1.035, translateY: mainAction ? -5 : -2, duration: mainAction ? 280 : 220, ease: "out(4)" });
    const leave = () => animate(element, { scale: 1, translateX: 0, translateY: 0, duration: 280, ease: "out(3)" });
    const move = (event: PointerEvent) => { const rect = element.getBoundingClientRect(); const x = ((event.clientX - rect.left) / rect.width - 0.5) * (mainAction ? 9 : 5); const y = ((event.clientY - rect.top) / rect.height - 0.5) * (mainAction ? 6 : 3); animate(element, { translateX: x, translateY: y + (mainAction ? -4 : -2), scale: mainAction ? 1.075 : 1.035, duration: 180, ease: "out(4)" }); };
    const press = () => animate(element, { scale: mainAction ? 0.95 : 0.96, duration: 110, ease: "out(4)" });
    element.addEventListener("pointerenter", enter); element.addEventListener("pointerleave", leave); element.addEventListener("pointermove", move); element.addEventListener("pointerdown", press); element.addEventListener("pointerup", enter); element.addEventListener("focus", enter); element.addEventListener("blur", leave);
    element.addEventListener("__motion_cleanup", () => { element.removeEventListener("pointerenter", enter); element.removeEventListener("pointerleave", leave); element.removeEventListener("pointermove", move); element.removeEventListener("pointerdown", press); element.removeEventListener("pointerup", enter); element.removeEventListener("focus", enter); element.removeEventListener("blur", leave); });
  });
  const visualTargets = Array.from(document.querySelectorAll<MotionElement>("[data-pop], .algorithm-page .pipeline-card, .algorithm-page .stage-card, .algorithm-page .mode-explainer, .algorithm-page .algorithm-diagram, .algorithm-page .threshold-card, .rv-site .rv-banana, .rv-site img"));
  visualTargets.forEach((element) => {
    if (element.__motionBound) return;
    element.__motionBound = true;
    const enter = () => animate(element, { scale: 1.035, rotate: element.matches(".rv-banana") ? 2 : 0, duration: 360, ease: "out(4)" });
    const leave = () => animate(element, { scale: 1, rotate: 0, duration: 420, ease: "out(3)" });
    const press = () => animate(element, { scale: .975, duration: 120, ease: "out(4)" });
    element.addEventListener("pointerenter", enter); element.addEventListener("pointerleave", leave); element.addEventListener("pointerdown", press); element.addEventListener("pointerup", enter);
    element.addEventListener("__motion_cleanup", () => { element.removeEventListener("pointerenter", enter); element.removeEventListener("pointerleave", leave); element.removeEventListener("pointerdown", press); element.removeEventListener("pointerup", enter); });
  });
}

function revealText() {
  document.querySelectorAll<HTMLElement>(".algorithm-page .algorithm-hero h1, .algorithm-page .algorithm-lede, .rv-site .rv-hero h1, .rv-site .rv-hero .rv-lede").forEach((element) => {
    if (element.dataset.splitReady) return;
    element.dataset.splitReady = "true";
    const split = splitText(element, { words: true });
    animate(split.words, { opacity: [0, 1], translateY: [18, 0], delay: stagger(24), duration: 620, ease: "out(4)" });
  });
  document.querySelectorAll<HTMLElement>(".rv-logo, .algorithm-brand, .app-header .brand-mark").forEach((element) => {
    if (element.dataset.charReady) return;
    element.dataset.charReady = "true";
    const split = splitText(element, { chars: true });
    animate(split.chars, { opacity: [0, 1], translateY: [{ to: "-0.35rem", duration: 320 }, { to: 0, duration: 580, delay: 60 }], rotate: { from: "-0.12turn", to: 0 }, delay: stagger(42), ease: "out(4)" });
  });
}

export default function MotionLayer() {
  useEffect(() => {
    let observer: IntersectionObserver | undefined;
    let cancelled = false;
    const setup = () => {
      if (cancelled) return;
      const targets = Array.from(document.querySelectorAll<HTMLElement>(".rv-site section, .rv-site footer, .view-shell > *, .sidebar, .app-header, .history-panel, .history-summary"));
      observer = new IntersectionObserver((entries) => { entries.forEach((entry) => { if (!entry.isIntersecting) return; animate(entry.target, { opacity: [0, 1], translateY: [22, 0], duration: 700, ease: "out(4)" }); observer?.unobserve(entry.target); }); }, { threshold: 0.08 });
      targets.forEach((target, index) => { target.style.willChange = "transform, opacity"; observer?.observe(target); if (index < 4) animate(target, { opacity: [0, 1], translateY: [18, 0], delay: index * 90, duration: 620, ease: "out(4)" }); });
      bindMotion();
      revealText();
    };
    const frame = window.requestAnimationFrame(setup);
    const refresh = window.setTimeout(() => { bindMotion(); revealText(); }, 160);
    return () => { cancelled = true; window.cancelAnimationFrame(frame); window.clearTimeout(refresh); observer?.disconnect(); document.querySelectorAll<MotionElement>("button, a, select, input[type='range']").forEach((element) => element.dispatchEvent(new Event("__motion_cleanup"))); };
  }, []);
  return <><ScrollBanana /><ScrollProgress /><CursorFollower /></>;
}
